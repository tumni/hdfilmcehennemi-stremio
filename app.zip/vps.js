const { Client } = require('ssh2');

const conn = new Client();
const cmd = process.argv[2];

conn.on('ready', () => {
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code, signal) => {
      conn.end();
      process.exit(code);
    }).on('data', (data) => {
      process.stdout.write(data.toString());
    }).stderr.on('data', (data) => {
      process.stderr.write(data.toString());
    });
  });
}).connect({
  host: '89.252.153.147',
  port: 22,
  username: 'ubuntu',
  password: 'ch6mrmMghW2brR',
  readyTimeout: 20000
});
