const fs = require('fs');
const { Client } = require('ssh2');

const host = '89.252.153.147';
const username = 'ubuntu';
const password = 'ch6mrmMghW2brR';

async function upload() {
  console.log('Connecting to VPS...');
  const conn = new Client();
  conn.on('ready', () => {
    console.log('Connected. Starting SFTP...');
    conn.sftp((err, sftp) => {
      if (err) throw err;
      const readStream = fs.createReadStream('app.zip');
      const writeStream = sftp.createWriteStream('/home/ubuntu/app.zip');
      
      writeStream.on('close', () => {
        console.log('Upload complete. Unzipping on VPS...');
        conn.exec('rm -rf /home/ubuntu/hdfilmcehennemi-stremio && mkdir -p /home/ubuntu/hdfilmcehennemi-stremio && sudo apt update && sudo apt install unzip -y && unzip -q /home/ubuntu/app.zip -d /home/ubuntu/hdfilmcehennemi-stremio && cd /home/ubuntu/hdfilmcehennemi-stremio && chmod +x setup.sh && sudo ./setup.sh', { pty: true }, (err, stream) => {
          if (err) throw err;
          stream.on('close', (code, signal) => {
            console.log('VPS setup finished with code ' + code);
            conn.end();
            process.exit(code);
          }).on('data', (data) => {
            process.stdout.write(data.toString());
          }).stderr.on('data', (data) => {
            process.stderr.write(data.toString());
          });
        });
      });
      
      readStream.pipe(writeStream);
    });
  }).connect({
    host,
    port: 22,
    username,
    password,
    readyTimeout: 120000
  });
}

upload().catch(console.error);
